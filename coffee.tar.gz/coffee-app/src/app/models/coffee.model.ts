export class Coffee {
  id?: any;
  beans?: number;
  water?: number;
}
