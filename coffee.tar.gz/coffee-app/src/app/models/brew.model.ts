export class Brew {
  id?: any;
  size?: number;
  grain?: number;
  delay?: number;
}
