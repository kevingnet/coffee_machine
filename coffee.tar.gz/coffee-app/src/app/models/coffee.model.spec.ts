import { Coffee } from './coffee.model';

describe('Coffee', () => {
  it('should create an instance', () => {
    expect(new Coffee()).toBeTruthy();
  });
});
